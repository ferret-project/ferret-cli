# Cordless drill

![drill.jpg](files/drill.jpg)

## Details

- **Brand:** Example Tools
- **Serial number:** SN-0001
- **Value:** $110.00
- **Expected life:** about 8 years
- **Added:** Nov 24, 2026 · ann

## History

- Nov 24, 2026, 10:54 AM · Added a document to Cordless drill · ann
- Nov 24, 2026, 10:54 AM · Added a photo to Cordless drill · ann
- Nov 24, 2026, 10:54 AM · Added Cordless drill · ann

## Documents

- [receipt.pdf](files/receipt.pdf)

---

From Ferret, November 24, 2026: http://localhost:8787/#/items/baed965f-0130-4c9c-aa22-f40855922a7d
